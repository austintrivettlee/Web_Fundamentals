function addLike() {
    var likeCount = document.querySelector("#likes").innerText
    likeCount = parseFloat(likeCount)
    likeCount++;
    document.querySelector("#likes").innerText = likeCount
}
function addLike2() {
    var likeCount2 = document.querySelector("#likes2").innerText
    likeCount2 = parseFloat(likeCount2)
    likeCount2++;
    document.querySelector("#likes2").innerText = likeCount2
}
function addLike3() {
    var likeCount3 = document.querySelector("#likes3").innerText
    likeCount3 = parseFloat(likeCount3)
    likeCount3++;
    document.querySelector("#likes3").innerText = likeCount3
}