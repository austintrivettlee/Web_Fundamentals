function login() {
        var butLogin = document.querySelector("#loginbut").innerText;
        document.querySelector("#loginbut").innerText = "Logout";
}

function addButton(element) {
    element.remove();
}

function addLike(element) {
    alert("You have a Like!")
}